# Jyothsna Portfolio

Personal portfolio website.

### GitHub Pages
Upload all files in this folder to your GitHub repository, then enable:
Settings → Pages → Deploy from branch → main → /(root)

### Add your images
- `images/` → profile and general photos
- `images/projects/` → project screenshots
- `images/certificates/` → certificates and achievements
